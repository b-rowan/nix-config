# NMT

This is a basic test framework for projects using the Nixpkgs module
system. It is inspired by the [nix-darwin test framework][nix-darwin].

[nix-darwin]: https://github.com/LnL7/nix-darwin
