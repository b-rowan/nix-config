# Changelog

## 0.5.0 (2024-01-10)

* The first numbered release of nmt.
